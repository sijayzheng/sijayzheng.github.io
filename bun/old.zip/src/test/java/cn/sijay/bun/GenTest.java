package cn.sijay.bun;

import cn.sijay.bun.common.util.JSONUtil;
import cn.sijay.bun.gen.entity.GenColumn;
import cn.sijay.bun.gen.entity.GenTable;
import cn.sijay.bun.gen.service.GenColumnService;
import cn.sijay.bun.gen.service.GenService;
import cn.sijay.bun.gen.service.GenTableService;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.List;

/**
 * <strong>GenTest</strong>
 * <p>
 *
 * </p>
 *
 * @author sijay
 * @since 2024-11-01
 */
@SpringBootTest(classes = BunApplication.class)
public class GenTest {
    @Autowired
    private GenService genService;
    @Autowired
    private GenTableService tableService;
    @Autowired
    private GenColumnService columnService;

    @Test
    public void test() {
        List<String> existTables = tableService.findAll().parallelStream().map(GenTable::getTableName).toList();
        List<GenTable> tables = tableService.getAllTable().stream()
                                            .filter(item -> !existTables.contains(item.getTableName()))
                                            .toList();
        for (GenTable table : tables) {
            System.out.println(JSONUtil.toJSONString(table));
            List<GenColumn> columns = columnService.getColumnByTableName(table.getTableName());
            for (GenColumn column : columns) {
                System.out.println(JSONUtil.toJSONString(column));
            }
        }
    }

    @Test
    public void autoImport() {
        genService.autoImport();
    }

    @Test
    public void generate() {
        for (long i = 4; i < 15; i++) {
            genService.generate(i);
        }
    }
}
