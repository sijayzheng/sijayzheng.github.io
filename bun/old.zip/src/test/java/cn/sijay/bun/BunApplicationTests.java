package cn.sijay.bun;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BunApplicationTests {

    @Test
    void contextLoads() {

    }

}
