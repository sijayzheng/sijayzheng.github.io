package cn.sijay.bun.test;

/**
 * <strong>Main</strong>
 * <p>
 *
 * </p>
 *
 * @author sijay
 * @since 2024-12-24
 */
public class Main {
    public static void main(String[] args) {
    }
}
