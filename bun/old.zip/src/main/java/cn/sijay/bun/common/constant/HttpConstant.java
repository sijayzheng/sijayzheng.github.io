package cn.sijay.bun.common.constant;

/**
 * <strong>HttpConstant</strong>
 * <p>
 *
 * </p>
 *
 * @author sijay
 * @since 2024-11-06
 */
public interface HttpConstant {

    Integer OK = 200;
    Integer FAIL = 500;
}
