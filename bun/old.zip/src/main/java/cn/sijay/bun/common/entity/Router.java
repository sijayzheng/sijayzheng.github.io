package cn.sijay.bun.common.entity;

import lombok.Data;

/**
 * <strong>Router</strong>
 * <p>
 *
 * </p>
 *
 * @author sijay
 * @since 2024-12-10
 */
@Data
public class Router {
}
