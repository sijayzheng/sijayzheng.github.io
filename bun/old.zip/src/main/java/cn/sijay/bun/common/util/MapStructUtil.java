package cn.sijay.bun.common.util;

import io.github.linpeilie.Converter;
import lombok.AccessLevel;
import lombok.NoArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.ObjectUtils;

import java.util.List;
import java.util.Map;

/**
 * <strong>MapStructUtil</strong>
 * <p>
 *
 * </p>
 *
 * @author sijay
 * @since 2024-11-20
 */
@Slf4j
@NoArgsConstructor(access = AccessLevel.PRIVATE)
public class MapStructUtil {
    private static final Converter CONVERTER = SpringUtil.getBean(Converter.class);

    public static <S, T> T convert(S source, Class<T> targetClass) {
        if (ObjectUtils.isEmpty(source) || ObjectUtils.isEmpty(targetClass)) {
            return null;
        }
        return CONVERTER.convert(source, targetClass);
    }

    public static <S, T> T convert(S source, T target) {
        if (ObjectUtils.isEmpty(source) || ObjectUtils.isEmpty(target)) {
            return null;
        }
        return CONVERTER.convert(source, target);
    }

    public static Converter getConverter() {
        return CONVERTER;
    }

    public static <S, T> List<T> convert(List<S> source, Class<T> targetType) {
        return CONVERTER.convert(source, targetType);
    }

    public static <T> T convert(Map<String, Object> map, Class<T> target) {
        return CONVERTER.convert(map, target);
    }
}
