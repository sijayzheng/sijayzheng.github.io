package cn.sijay.bun.gen.constants;

import java.util.List;

/**
 * <strong>GenConstants</strong>
 * <p>
 *
 * </p>
 *
 * @author sijay
 * @since 2024-11-08
 */
public interface GenConstants {
    List<String> AUTO_FIELD = List.of("create_dept", "create_by", "create_date", "update_by", "update_date");
}
