package cn.sijay.bun.common.entity;

import lombok.Data;

/**
 * <strong>Mate</strong>
 * <p>
 *
 * </p>
 *
 * @author sijay
 * @since 2024-12-10
 */
@Data
public class Mate {
}
