<template>
  <div>
    <el-card class="search-card" shadow="hover">
      <div v-show="showSearch" class="search-container">
        <el-form ref="queryFormRef" :inline="true" :model="queryParams">
          <el-form-item label="公告标题" prop="noticeTitle">
            <el-input v-model="queryParams.noticeTitle" clearable placeholder="请输入公告标题" @keyup.enter="handleQuery" />
          </el-form-item>
          <el-form-item label="类型" prop="noticeType">
            <el-select v-model="queryParams.noticeType" clearable placeholder="公告类型">
              <el-option v-for="dict in sys_notice_type" :key="dict.value" :label="dict.label" :value="dict.value" />
            </el-select>
          </el-form-item>
          <el-form-item>
            <el-button icon="Search" type="primary" @click="handleQuery">搜索</el-button>
            <el-button icon="Refresh" @click="resetQuery">重置</el-button>
          </el-form-item>
        </el-form>
      </div>
      <el-row :gutter="10">
        <el-col :span="1.5">
          <el-button icon="Plus" plain type="primary" @click="handleAdd">新增</el-button>
        </el-col>
        <el-col :span="1.5">
          <el-button :disabled="ids.length === 0" icon="Delete" plain type="danger" @click="handleDelete()">删除</el-button>
        </el-col>
        <table-toolbar v-model:show-search="showSearch" :columns="columns" @query-table="getList" />
      </el-row>
    </el-card>
    <div class="table-container">
      <el-table :data="data" :loading="loading" border max-height="600" stripe @selection-change="handleSelectionChange">
        <el-table-column type="selection" width="50" />
        <el-table-column v-if="false" label="序号" type="index" width="50" />
        <template v-for="item in columns" :key="item.prop">
          <el-table-column v-if="item.visible" :label="item.label" :prop="item.prop" />
        </template>
      </el-table>
      <pagination
        v-show="total > 0"
        v-model:limit="queryParams.pageSize"
        v-model:page="queryParams.pageNum"
        :selection="ids.length"
        :total="total"
        @pagination="getList"
      />
    </div>
  </div>
</template>

<script setup>
const showSearch = ref(true)
const queryFormRef = ref()
const queryParams = ref({
  pageNum: 1,
  pageSize: 10,
  noticeTitle: '',
  noticeType: '',
})
const columns = ref([
  {
    label: 'id',
    prop: 'id',
    width: 20,
    visible: true,
  },
  {
    label: '姓名',
    prop: 'name',
    width: 20,
    visible: true,
  },
  {
    label: '权限',
    prop: 'role',
    width: 20,
    visible: true,
  },
  {
    label: '性别',
    prop: 'sex',
    width: 20,
    visible: true,
  },
  {
    label: '年龄',
    prop: 'age',
    width: 20,
    visible: true,
  },
  {
    label: '地址',
    prop: 'address',
    width: 20,
    visible: true,
  },
])
const data = ref([])
const loading = ref(false)
const total = ref(0)
const ids = ref([])

const sys_notice_type = ref([])

const getList = () => {}
const handleQuery = () => {}
const resetQuery = () => {}
const handleAdd = () => {}
const handleDelete = () => {
  console.log(ids.value)
}
const handleSelectionChange = (val) => {
  ids.value = val.map((item) => item.id)
}

onMounted(() => {
  setTimeout(() => {
    const arr = [
      {
        id: 10001,
        name: 'Test1',
        role: 'Develop',
        sex: 'Man',
        age: 28,
        address: 'test abc',
      },
      {
        id: 10002,
        name: 'Test2',
        role: 'Test',
        sex: 'Women',
        age: 22,
        address: 'Guangzhou',
      },
      {
        id: 10003,
        name: 'Test3',
        role: 'PM',
        sex: 'Man',
        age: 32,
        address: 'Shanghai',
      },
      {
        id: 10004,
        name: 'Test4',
        role: 'Designer',
        sex: 'Women',
        age: 24,
        address: 'Shanghai',
      },
      {
        id: 10005,
        name: 'Test4',
        role: 'Designer',
        sex: 'Women',
        age: 24,
        address: 'Shanghai',
      },
      {
        id: 10006,
        name: 'Test4',
        role: 'Designer',
        sex: 'Women',
        age: 24,
        address: 'Shanghai',
      },
      {
        id: 10007,
        name: 'Test4',
        role: 'Designer',
        sex: 'Women',
        age: 24,
        address: 'Shanghai',
      },
      {
        id: 10008,
        name: 'Test4',
        role: 'Designer',
        sex: 'Women',
        age: 24,
        address: 'Shanghai',
      },
      {
        id: 10009,
        name: 'Test4',
        role: 'Designer',
        sex: 'Women',
        age: 24,
        address: 'Shanghai',
      },
      {
        id: 10010,
        name: 'Test4',
        role: 'Designer',
        sex: 'Women',
        age: 24,
        address: 'Shanghai',
      },
      {
        id: 10011,
        name: 'Test4',
        role: 'Designer',
        sex: 'Women',
        age: 24,
        address: 'Shanghai',
      },
      {
        id: 10012,
        name: 'test5',
        role: 'Designer',
        sex: 'Women',
        age: 24,
        address: 'Shanghai',
      },
      {
        id: 10013,
        name: 'Test4',
        role: 'Designer',
        sex: 'Women',
        age: 24,
        address: 'Shanghai',
      },
      {
        id: 10014,
        name: 'Test4',
        role: 'Designer',
        sex: 'Women',
        age: 24,
        address: 'Shanghai',
      },
      {
        id: 10015,
        name: 'Test4',
        role: 'Designer',
        sex: 'Women',
        age: 24,
        address: 'Shanghai',
      },
      {
        id: 10016,
        name: 'Test4',
        role: 'Designer',
        sex: 'Women',
        age: 24,
        address: 'Shanghai',
      },
      {
        id: 10017,
        name: 'Test4',
        role: 'Designer',
        sex: 'Women',
        age: 24,
        address: 'Shanghai',
      },
      {
        id: 10018,
        name: 'Test4',
        role: 'Designer',
        sex: 'Women',
        age: 24,
        address: 'Shanghai',
      },
      {
        id: 10019,
        name: 'Test4',
        role: 'Designer',
        sex: 'Women',
        age: 24,
        address: 'Shanghai',
      },
      {
        id: 10020,
        name: 'Test4',
        role: 'Designer',
        sex: 'Women',
        age: 24,
        address: 'Shanghai',
      },
      {
        id: 10021,
        name: 'Test4',
        role: 'Designer',
        sex: 'Women',
        age: 24,
        address: 'Shanghai',
      },
      {
        id: 10022,
        name: 'Test4',
        role: 'Designer',
        sex: 'Women',
        age: 24,
        address: 'Shanghai',
      },
      {
        id: 10023,
        name: 'Test4',
        role: 'Designer',
        sex: 'Women',
        age: 24,
        address: 'Shanghai',
      },
      {
        id: 10024,
        name: 'Test4',
        role: 'Designer',
        sex: 'Women',
        age: 24,
        address: 'Shanghai',
      },
      {
        id: 10025,
        name: 'Test4',
        role: 'Designer',
        sex: 'Women',
        age: 24,
        address: 'Shanghai',
      },
      {
        id: 10026,
        name: 'Test4',
        role: 'Designer',
        sex: 'Women',
        age: 24,
        address: 'Shanghai',
      },
    ]

    data.value = arr
    total.value = arr.length
  }, 2000)
})
</script>
