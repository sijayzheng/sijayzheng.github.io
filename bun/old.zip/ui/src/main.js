import { createApp } from 'vue'
import App from './App.vue'
import 'dayjs/locale/zh-cn'
import './styles/element.scss'
import ElementPlus from 'element-plus'
import 'element-plus/dist/index.css'
import './styles/index.scss'
import 'virtual:uno.css'

import * as ElementPlusIconsVue from '@element-plus/icons-vue'

import VXETable from 'vxe-table'
import 'vxe-table/lib/style.css'
// svg图标
import 'virtual:svg-icons-register'

import HighLight from '@highlightjs/vue-plugin'
import 'highlight.js/lib/common'
import 'highlight.js/styles/atom-one-dark.css'

// import directive from './directive'
// import './permission'
import router from './router'
import store from './store'

const app = createApp(App)
app.use(ElementPlus)
app.use(store)
app.use(router)

for (const [key, component] of Object.entries(ElementPlusIconsVue)) {
  app.component(key, component)
}
VXETable.setConfig({
  zIndex: 999999,
})
app.use(VXETable)
app.use(HighLight)

// ElDialog.props.closeOnClickModal.default = false;

// app.use(plugins)
// 自定义指令
// directive(app)

app.mount('#app')
