<template>
  <el-config-provider :button="{ autoInsertSpace: true }" :locale="zhCn" :message="message" :size="appStore.size">
    <router-view />
  </el-config-provider>
</template>

<script setup>
import zhCn from 'element-plus/es/locale/lang/zh-cn'

const appStore = useSettingsStore()
const message = {
  max: 3,
  duration: 2500,
  showClose: true,
}
onMounted(() => {
  nextTick(() => {
    // 初始化主题样式
    handleThemeStyle(useSettingsStore().theme)
  })
})
</script>
