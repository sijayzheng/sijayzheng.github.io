<template>
  <div class="navbar">
    <hamburger id="hamburger-container" :is-active="settingsStore.sidebar.opened" class="hamburger-container" @toggle-click="toggleSideBar" />
    <breadcrumb id="breadcrumb-container" class="breadcrumb-container" />
    <div class="right-menu flex align-center">
      <!-- 消息 -->
      <el-tooltip content="消息">
        <div>
          <el-popover :persistent="false" :width="300" placement="bottom" transition="el-zoom-in-top" trigger="click">
            <template #reference>
              <el-badge :max="99" :value="newNotice > 0 ? newNotice : ''">
                <svg-icon icon-class="message" />
              </el-badge>
            </template>
            <template #default>
              <notice></notice>
            </template>
          </el-popover>
        </div>
      </el-tooltip>
      <el-tooltip content="全屏">
        <screen-full id="screenfull" class="right-menu-item hover-effect" />
      </el-tooltip>
      <el-tooltip content="布局大小">
        <size-select id="size-select" class="right-menu-item hover-effect" />
      </el-tooltip>
      <el-tooltip content="深色">
        <el-switch v-model="isDark" class="drawer-switch" @change="toggleDark" />
      </el-tooltip>

      <div class="avatar-container">
        <el-dropdown class="right-menu-item hover-effect" @command="handleCommand">
          <div class="avatar-wrapper">
            <img :src="userStore.avatar" alt="头像" class="user-avatar" />
            <el-icon>
              <caret-bottom />
            </el-icon>
          </div>
          <template #dropdown>
            <el-dropdown-menu>
              <router-link to="/user/profile">
                <el-dropdown-item>个人中心</el-dropdown-item>
              </router-link>
              <el-dropdown-item command="logout" divided>
                <span>退出登录</span>
              </el-dropdown-item>
            </el-dropdown-menu>
          </template>
        </el-dropdown>
      </div>
    </div>
  </div>
</template>

<script setup>
import { CaretBottom } from '@element-plus/icons-vue'

const userStore = useUserStore()
const settingsStore = useSettingsStore()

const newNotice = ref(0)
const theme = ref(settingsStore.theme)
// 是否暗黑模式
const isDark = useDark({
  storageKey: 'useDarkKey',
  valueDark: 'dark',
  valueLight: 'light',
})
const predefineColors = ref(['#409eff', '#ff4500', '#ff8c00', '#ffd700', '#90ee90', '#00ced1', '#1e90ff', '#c71585'])

const storeSettings = computed(() => settingsStore)

//用深度监听 消息
watch(
  () => useNoticeStore().state.notices,
  (newVal) => {
    newNotice.value = newVal.filter((item) => !item.read).length
  },
  { deep: true },
)

const toggleSideBar = () => {
  settingsStore.toggleSideBar()
}

const logout = async () => {
  await ElMessageBox.confirm('确定注销并退出系统吗？', '提示', {
    confirmButtonText: '确定',
    cancelButtonText: '取消',
    type: 'warning',
  })
  userStore.logout().then(() => {
    router.replace({
      path: '/login',
      query: {
        redirect: encodeURIComponent(router.currentRoute.value.fullPath || '/'),
      },
    })
  })
}

const toggleDark = () => {
  useToggle(isDark)
}

const commandMap = {
  logout,
}

const handleCommand = (command) => {
  // 判断是否存在该方法
  if (commandMap[command]) {
    commandMap[command]()
  }
}
</script>

<style lang="scss" scoped>
:deep(.el-select .el-input__wrapper) {
  height: 30px;
}

:deep(.el-badge__content.is-fixed) {
  top: 12px;
}

.flex {
  display: flex;
}

.align-center {
  align-items: center;
}

.navbar {
  height: 50px;
  overflow: hidden;
  position: relative;
  //background: #fff;
  box-shadow: 0 1px 4px rgba(0, 21, 41, 0.08);

  .hamburger-container {
    line-height: 46px;
    height: 100%;
    float: left;
    cursor: pointer;
    transition: background 0.3s;
    -webkit-tap-highlight-color: transparent;

    &:hover {
      background: rgba(0, 0, 0, 0.025);
    }
  }

  .breadcrumb-container {
    float: left;
  }

  .top-menu-container {
    position: absolute;
    left: 50px;
  }

  .errLog-container {
    display: inline-block;
    vertical-align: top;
  }

  .right-menu {
    float: right;
    height: 100%;
    line-height: 50px;
    display: flex;

    &:focus {
      outline: none;
    }

    .right-menu-item {
      display: inline-block;
      padding: 0 8px;
      height: 100%;
      font-size: 18px;
      color: #5a5e66;
      vertical-align: text-bottom;

      &.hover-effect {
        cursor: pointer;
        transition: background 0.3s;

        &:hover {
          background: rgba(0, 0, 0, 0.025);
        }
      }
    }

    .avatar-container {
      margin-right: 40px;

      .avatar-wrapper {
        margin-top: 5px;
        position: relative;

        .user-avatar {
          cursor: pointer;
          width: 40px;
          height: 40px;
          border-radius: 10px;
          margin-top: 10px;
        }

        i {
          cursor: pointer;
          position: absolute;
          right: -20px;
          top: 25px;
          font-size: 12px;
        }
      }
    }
  }
}
</style>
