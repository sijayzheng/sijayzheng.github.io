<template>
  <div class="has-logo">
    <logo :collapse="isCollapse" />
    <el-scrollbar wrap-class="scrollbar-wrapper">
      <transition enter-active-class="animate__animated animate__fadeIn" mode="out-in">
        <el-menu
          :active-text-color="theme"
          :collapse="isCollapse"
          :collapse-transition="false"
          :default-active="activeMenu"
          :unique-opened="true"
          mode="vertical"
        >
          <sidebar-item v-for="(r, index) in sidebarRouters" :key="r.path + index" :base-path="r.path" :item="r" />
        </el-menu>
      </transition>
    </el-scrollbar>
  </div>
</template>

<script setup>
const route = useRoute()
const settingsStore = useSettingsStore()
const permissionStore = usePermissionStore()
const sidebarRouters = computed(() => permissionStore.getSidebarRoutes())
const theme = computed(() => settingsStore.theme)
const isCollapse = computed(() => !settingsStore.sidebar.opened)

const activeMenu = computed(() => {
  const { meta, path } = route
  if (meta.activeMenu) {
    return meta.activeMenu
  }
  return path
})
</script>
