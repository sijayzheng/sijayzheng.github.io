import copyText from './common/copyText'
import { hasPermi, hasRoles } from './permission'

export default (app) => {
  app.directive('copyText', copyText)
  app.directive('hasPermi', hasPermi)
  app.directive('hasRoles', hasRoles)
}
