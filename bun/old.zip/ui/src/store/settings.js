import { defineStore } from 'pinia'
import { useDynamicTitle } from '@/util/dynamicTitle'
import variables from '@/styles/variables.module.scss'

export const useSettingsStore = defineStore('setting', () => {
  const storageSetting = useStorage('layout-setting', {
    theme: variables.primaryColor,
    dark: false,
  })
  const title = ref(import.meta.env.VITE_APP_TITLE)
  const theme = ref(storageSetting.value.theme)
  const sidebarStatus = useStorage('sidebarStatus', '1')
  const sidebar = reactive({
    opened: sidebarStatus.value ? !!+sidebarStatus.value : true,
    withoutAnimation: false,
    hide: false,
  })
  const size = useStorage('size', 'default')

  const toggleSideBar = () => {
    if (sidebar.hide) {
      return false
    }
    sidebar.opened = !sidebar.opened
    if (sidebar.opened) {
      sidebarStatus.value = '1'
    } else {
      sidebarStatus.value = '0'
    }
  }

  const setSize = (s) => {
    size.value = s
  }
  const toggleSideBarHide = (status) => {
    sidebar.hide = status
  }

  const setTitle = (value) => {
    title.value = value
    useDynamicTitle()
  }
  const isDark = useDark({
    storageKey: 'useDarkKey',
    valueDark: 'dark',
    valueLight: 'light',
  })

  const dark = ref(false)
  watch(
    () => isDark.value,
    () => {
      console.log(isDark.value)
      dark.value = isDark.value
    },
  )
  return {
    title,
    theme,
    setTitle,
    sidebar,
    size,
    dark,
    toggleSideBar,
    setSize,
    toggleSideBarHide,
  }
})

export default useSettingsStore
