import globals from 'globals'
import js from '@eslint/js'
import pluginVue from 'eslint-plugin-vue'
import prettier from 'eslint-plugin-prettier/recommended'
import parserVue from 'vue-eslint-parser'
import { readFile } from 'node:fs/promises'

const autoImportFile = new URL('./.eslintrc-auto-import.json', import.meta.url)
const autoImportGlobals = JSON.parse(await readFile(autoImportFile, 'utf8'))
export default [
  {
    files: ['*.js', '*.mjs', '*.cjs', '*.jsx', '*.ts', '*.tsx', '*.vue'],
  },
  {
    ignores: [
      '*.sh',
      'node_modules',
      'dist',
      '*.md',
      '*.woff',
      '*.ttf',
      '.vscode',
      '.idea',
      '/public',
      '/docs',
      '.husky',
      '.local',
      '/bin',
      'src/assets',
      'eslint.config.js',
      'auto-imports.d.ts',
      'components.d.ts',
    ],
  },
  js.configs.recommended,
  ...pluginVue.configs['flat/recommended'],
  prettier,
  {
    languageOptions: {
      globals: {
        ...globals.browser,
        ...globals.es2023,
        ...autoImportGlobals.globals,
        DialogOption: 'readonly',
        OptionType: 'readonly',
      },
      ecmaVersion: 'latest',
      sourceType: 'module',
      parser: parserVue,
      parserOptions: {
        project: './tsconfig.json',
        extraFileExtensions: ['.vue'],
      },
    },
    rules: {
      'vue/multi-word-component-names': 'off',
      'vue/valid-define-props': 'off',
      'vue/no-v-model-argument': 'off',
      'vue/no-unused-vars': 'off',
      'vue/no-undef': 'off',
      // 'vue/html-closing-bracket-newline': 'off',

      'prefer-rest-params': 'off',

      'prettier/prettier': 'error',

      'no-unused-vars': 'off',
      'no-undef': 'off',
    },
  },
]
